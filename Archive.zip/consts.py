data_file_path = "./mental_disorder_prediction.csv"
mental_disorder_trained_model_filename = "mental_disorder_trained_model.pickle"
labels_filename = "labels.json"